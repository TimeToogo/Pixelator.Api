﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Physics_box
{
    public class environment
    {
        public int gravity = 100;
        public int friction = 100;
        public int air_resistance = 20;
        public int wind = 0;
        public bool single_screen = true;
    }
}
